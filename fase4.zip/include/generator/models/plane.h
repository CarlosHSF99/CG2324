#ifndef CG2324_PLANE_H
#define CG2324_PLANE_H


#include "model.h"

class Plane : public Model
{
public:
    Plane(double size, int divisions);
};


#endif //CG2324_PLANE_H
