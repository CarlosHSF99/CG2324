#ifndef CG2324_BOX_H
#define CG2324_BOX_H


#include "model.h"

class Box : public Model
{
public:
    Box(double size, int divisions);
};


#endif //CG2324_BOX_H
